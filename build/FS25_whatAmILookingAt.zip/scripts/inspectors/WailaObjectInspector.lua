WailaObjectInspector = {}
local WailaObjectInspector_mt = Class(WailaObjectInspector)

function WailaObjectInspector.new()
    return setmetatable({}, WailaObjectInspector_mt)
end

function WailaObjectInspector:inspect(hit)
    local nodeId = hit.nodeId
    local object = g_currentMission ~= nil and g_currentMission:getNodeObject(nodeId) or nil
    local rigidBodyType = WailaUtil.safeGlobalCall("getRigidBodyType", nil, nodeId)
    local nodeName = WailaUtil.safeGlobalCall("getName", nil, nodeId)
    local parent = WailaUtil.safeGlobalCall("getParent", nil, nodeId)
    local isSplitShape = false

    if getHasClassId ~= nil and ClassIds ~= nil and ClassIds.MESH_SPLIT_SHAPE ~= nil then
        isSplitShape = getHasClassId(nodeId, ClassIds.MESH_SPLIT_SHAPE)
    end

    local splitType = isSplitShape and WailaUtil.safeGlobalCall("getSplitType", nil, nodeId) or nil
    local split = isSplitShape and WailaUtil.safeGlobalCall("getIsSplitShapeSplit", nil, nodeId) or nil

    local kind = "node"
    if nodeId == g_currentMission.terrainRootNode or nodeId == g_terrainNode then
        kind = "terrain"
    elseif isSplitShape then
        if rigidBodyType == RigidBodyType.STATIC and not split then
            kind = "tree"
        elseif rigidBodyType == RigidBodyType.STATIC and split then
            kind = "stump/static split shape"
        elseif rigidBodyType == RigidBodyType.DYNAMIC then
            kind = "log/branch"
        else
            kind = "split shape"
        end
    elseif object ~= nil then
        if object.isVehicle or (Vehicle ~= nil and object.isa ~= nil and object:isa(Vehicle)) then
            kind = "vehicle"
        elseif Placeable ~= nil and object.isa ~= nil and object:isa(Placeable) then
            kind = "placeable"
        else
            kind = "game object"
        end
    end

    local ownerFarmId = nil
    if object ~= nil and object.getOwnerFarmId ~= nil then
        ownerFarmId = WailaUtil.safeCall(nil, object.getOwnerFarmId, object)
    end

    return {
        kind = kind,
        nodeId = nodeId,
        nodeName = nodeName,
        parentNodeId = parent,
        object = object,
        objectClass = WailaUtil.className(object),
        ownerFarmId = ownerFarmId,
        rigidBodyType = rigidBodyType,
        rigidBodyTypeName = WailaUtil.rigidBodyTypeName(rigidBodyType),
        isSplitShape = isSplitShape,
        splitType = splitType,
        isSplit = split,
        volume = isSplitShape and WailaUtil.safeGlobalCall("getVolume", nil, nodeId) or nil,
        mass = WailaUtil.safeGlobalCall("getMass", nil, nodeId),
        isSleeping = WailaUtil.safeGlobalCall("getIsSleeping", nil, nodeId)
    }
end
