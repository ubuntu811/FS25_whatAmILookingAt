WailaHud = {}
local WailaHud_mt = Class(WailaHud)

function WailaHud.new()
    local self = setmetatable({}, WailaHud_mt)
    self.x = 0.02
    self.y = 0.94
    self.lineHeight = 0.018
    self.textSize = 0.014
    self.maxStatsRows = 6
    return self
end

function WailaHud:drawLine(text, line, bold)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(bold == true)
    setTextColor(1, 1, 1, 1)
    renderText(self.x, self.y - line * self.lineHeight, self.textSize, text)
end

function WailaHud:draw(inspection, areaSize, areaStep)
    local line = 0
    self:drawLine("WHAT AM I LOOKING AT?", line, true)
    line = line + 1

    if inspection == nil or inspection.hit == nil then
        self:drawLine("No target", line)
        setTextBold(false)
        return
    end

    local hit = inspection.hit
    local object = inspection.object
    self:drawLine(string.format("Target: %s", object and object.kind or "unknown"), line, true); line = line + 1
    self:drawLine(string.format("Position: %.2f / %.2f / %.2f", hit.x, hit.y, hit.z), line); line = line + 1
    self:drawLine(string.format("Node: %s  name=%s", tostring(hit.nodeId), WailaUtil.value(object and object.nodeName)), line); line = line + 1
    self:drawLine(string.format("Physics: %s  sleeping=%s", WailaUtil.value(object and object.rigidBodyTypeName), WailaUtil.bool(object and object.isSleeping)), line); line = line + 1

    if object ~= nil and object.objectClass ~= nil then
        self:drawLine(string.format("Object: %s  farm=%s", object.objectClass, WailaUtil.value(object.ownerFarmId)), line); line = line + 1
    end

    if object ~= nil and object.isSplitShape then
        self:drawLine(string.format("Split shape: type=%s split=%s volume=%s", WailaUtil.value(object.splitType), WailaUtil.bool(object.isSplit), WailaUtil.value(object.volume)), line); line = line + 1
    end

    local terrain = inspection.terrain
    if terrain ~= nil then
        self:drawLine(string.format("Ground: %s [%s]  field=%s", terrain.materialName, tostring(terrain.materialId), WailaUtil.bool(terrain.isOnField)), line, true); line = line + 1
        self:drawLine(string.format("Ground type=%s densityBits=%s depth=%s", WailaUtil.value(terrain.groundType), WailaUtil.value(terrain.densityBits), WailaUtil.value(terrain.depth)), line); line = line + 1
    end

    local foliagePoint = inspection.foliagePoint or {}
    local names = {}
    for _, entry in ipairs(foliagePoint) do
        table.insert(names, string.format("%s(%s)", entry.name, tostring(entry.density)))
    end
    self:drawLine("Foliage here: " .. (#names > 0 and table.concat(names, ", ") or "<empty>"), line); line = line + 1

    self:drawLine(string.format("AREA %.0fx%.0fm / step %.2fm", areaSize, areaSize, areaStep), line, true); line = line + 1

    if inspection.terrainArea ~= nil then
        self:drawLine(string.format("Field coverage: %.1f%%", inspection.terrainArea.fieldPercent), line); line = line + 1
        for index, row in ipairs(inspection.terrainArea.materials) do
            if index > self.maxStatsRows then break end
            self:drawLine(string.format("  Ground %-18s %5.1f%% (%d)", row.name, row.percent, row.count), line); line = line + 1
        end
    end

    if inspection.foliageArea ~= nil then
        for index, row in ipairs(inspection.foliageArea.foliage) do
            if index > self.maxStatsRows then break end
            self:drawLine(string.format("  Foliage %-17s %5.1f%% (%d)", row.name, row.percent, row.count), line); line = line + 1
        end
    end

    self:drawLine("Shift+J: dump current target", line)
    setTextBold(false)
end
